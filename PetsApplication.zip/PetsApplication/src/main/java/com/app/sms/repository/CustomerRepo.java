package com.app.sms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.app.sms.model.Customer;

import jakarta.transaction.Transactional;

@Repository
public interface CustomerRepo extends JpaRepository<Customer,Integer>{
	Customer findBycustName(String custName);
	@Transactional
	@Modifying
	@Query("update Customer c set c.custAddress= :address where c.custId= :id")
	public void updateCustomerOnId(@Param(value ="address")
	String address,@Param(value="id")int id);


}
