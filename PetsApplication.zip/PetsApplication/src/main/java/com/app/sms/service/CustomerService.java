package com.app.sms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.sms.dto.CustomerRequest;
import com.app.sms.dto.CustomerResponse;
import com.app.sms.model.Customer;
import com.app.sms.repository.CustomerRepo;



@Service 
public class CustomerService {
	@Autowired
	CustomerRepo custrepo;

	public CustomerResponse addCustomer(CustomerRequest customer) {
		// TODO Auto-generated method stub
	 Customer cust = customeRequest(customer); 
	 Customer response = custrepo.save(cust);
	 CustomerResponse customerResponse = new CustomerResponse();
	 if(response!=null) {
		 customerResponse.setCustomer(response);
		 customerResponse.setStatus("SUCCESS");
	 }else {
		 customerResponse.setCustomer(cust);
		 customerResponse.setStatus("Fail");
	 }
		return customerResponse;
	}

	private Customer customeRequest(CustomerRequest customer) {
		// TODO Auto-generated method stub
		Customer cust = new Customer();
		cust.setCustName(customer.getCustName());
		cust.setCustId(customer.getCustId());
		cust.setCustAddress(customer.getCustAddress());
		cust.setMobile(customer.getMobile());
		return cust;
	}

	public CustomerResponse updateCustomer(CustomerRequest request) {
		// TODO Auto-generated method stub
		Customer res = custrepo.findById(request.getCustId()).get();
		CustomerResponse response= new CustomerResponse();
		if(res!=null) {
			Customer cust = new Customer();
			cust.setCustAddress(request.getCustAddress());
			Customer updatecust=custrepo.save(cust);
			if(updatecust!=null) {
				response.setCustomer(updatecust);
				response.setStatus("Updated");
			}
		}
		else {
			response.setStatus("Please check your Record in inserted..!");
		}
		return response;
	}

	public String deleteCustomer(int request) {
		// TODO Auto-generated method stub
		String sts ="FAIL";
		Customer c = custrepo.getById(request);
		if(c!=null) {
			custrepo.deleteById(request);
			sts= "Deleted";
		}else {
			sts = "Record not found...!";
		}
		return sts;
	}
	public java.util.List<Customer>getCustomer(){
		return custrepo.findAll();
	}
	
	
	
	
	

}
